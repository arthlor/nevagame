"""Source/geometry tests, not a substitute for Blender/export/game validation.

Run from the extracted package: python -m unittest discover -s tests -v
All runtime code under test is loaded from the delivered generators. Assembly
checks evaluate selected real Python functions with recording draw calls; they
do not claim to execute Blender, skinning, glTF, or the user's game.
"""
from __future__ import annotations
import ast
import builtins
import hashlib
import importlib
import json
import math
from pathlib import Path
import random
import subprocess
import symtable
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
GEN = ROOT / 'tools/blender/generators'
sys.path.insert(0, str(GEN.parent))
g = importlib.import_module('common.design_geometry')
CONTRACTS = json.loads((ROOT/'tests/contracts.json').read_text())


def load_functions(filename, names, env=None):
    """Execute unchanged function ASTs, without importing Blender-only modules."""
    tree = ast.parse((GEN/filename).read_text())
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    if {n.name for n in nodes} != set(names):
        raise AssertionError('Missing requested source functions')
    namespace = {'math': math, 'seeded_rng': random.Random, **(env or {})}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(GEN/filename), 'exec'), namespace)
    return namespace


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


class ClosedGeometryTests(unittest.TestCase):
    def test_seeded_shape_matrix(self):
        # 640 actual meshes spanning props, buildings, thin blades and large masses.
        for seed in range(80):
            rng = random.Random(seed)
            dims = tuple(10**rng.uniform(-2.0, 1.0) for _ in range(3))
            shapes = [
                g.crafted_box(dims, seed=seed),
                g.crafted_box(dims, bevel=0, seed=seed),
                g.canopy(dims, seed, sides=8 if seed%2 else 12),
                g.geological_mass(dims, seed, sides=8 if seed%2 else 12),
                g.lobed_volume(dims, seed, kind=('apple','tomato','bread','sack')[seed%4], sides=8),
                g.folded_leaf(dims[0],dims[1],rng.uniform(-math.pi,math.pi),
                              pitch=rng.uniform(.1,1),droop=rng.uniform(0,.4),seed=seed),
                g.draped_panel(dims[0],dims[1],dims[2],fold=min(dims)*.08),
                g.ridge_cap(dims[0],dims[1],dims[2]),
            ]
            for mesh in shapes:
                with self.subTest(seed=seed, verts=len(mesh.vertices)):
                    g.validate_mesh(mesh)
                    self.assertGreater(g.signed_volume(mesh), 0)

    def test_crafted_timber_stays_inside_envelope(self):
        for dimensions in ((.08,.09,6), (3,.06,.10), (.04,5,.05),(.01,.01,.01)):
            for seed in range(20):
                for point in g.crafted_box(dimensions, seed=seed).vertices:
                    for axis in range(3):
                        self.assertLessEqual(abs(point[axis]),dimensions[axis]*.5+1e-12)

    def test_explicit_zero_bevel_preserves_low_detail(self):
        mesh = g.crafted_box((.2,.4,4), bevel=0)
        self.assertEqual(len(mesh.vertices),8)
        self.assertEqual(sum(len(f)-2 for f in mesh.faces),12)

    def test_determinism_and_random_state_isolation(self):
        state = random.getstate()
        self.assertEqual(g.geological_mass((2,1,3),72), g.geological_mass((2,1,3),72))
        self.assertEqual(g.canopy((2,1,3),72), g.canopy((2,1,3),72))
        self.assertEqual(state,random.getstate())
        self.assertNotEqual(g.geological_mass((2,1,3),72),g.geological_mass((2,1,3),73))

    def test_stable_seed_across_processes(self):
        code = f"import sys;sys.path.insert(0,{str(GEN.parent)!r});from common.design_geometry import stable_seed;print(stable_seed('neva_oak'))"
        seed = subprocess.check_output([sys.executable,'-c',code],text=True).strip()
        self.assertEqual(seed,str(g.stable_seed('neva_oak')))

    def test_rotated_translated_shells_keep_winding_and_volume(self):
        shape = g.crafted_box((.2,.3,4), seed=3)
        moved = g.transformed(shape,location=(1234,-432,890),rotation=(.21,-.6,1.7))
        g.validate_mesh(moved)
        self.assertAlmostEqual(g.signed_volume(shape),g.signed_volume(moved),places=9)

    def test_brim_has_a_real_opening(self):
        mesh=g.hat_brim(.17,.365)
        g.validate_mesh(mesh)
        for x,y,z in mesh.vertices:
            self.assertGreaterEqual(math.hypot(x,y/.92),.17-1e-10)
        # Torus topology (a closed annulus), not a filled disk or open surface.
        edges={tuple(sorted((a,b))) for f in mesh.faces for a,b in zip(f,f[1:]+f[:1])}
        self.assertEqual(len(mesh.vertices)-len(edges)+len(mesh.faces),0)

    def test_invalid_inputs_are_rejected(self):
        for dim in ((0,1,2),(-1,2,3),(math.nan,1,2),(math.inf,1,2)):
            with self.assertRaises(ValueError):g.crafted_box(dim)
        with self.assertRaises(ValueError):g.hat_brim(.4,.3)
        with self.assertRaises(ValueError):g.crafted_box((1,2,3),bevel=-.1)
        with self.assertRaises(ValueError):list(g.clipped_courses(3,5,0,5))
        with self.assertRaises(ValueError):list(g.clipped_courses(3,5,3,2.5))
        with self.assertRaises(ValueError):g.lobed_volume((1,1,1),0,kind='unknown')

    def test_validator_rejects_missing_face_and_wrong_winding(self):
        good=g.crafted_box((1,1,1))
        with self.assertRaises(ValueError):g.validate_mesh(g.DesignMesh(good.vertices,good.faces[:-1]))
        bad=(tuple(reversed(good.faces[0])),)+good.faces[1:]
        with self.assertRaises(ValueError):g.validate_mesh(g.DesignMesh(good.vertices,bad))


class RoofGeometryTests(unittest.TestCase):
    def test_courses_are_clipped_and_staggered(self):
        for rows in (1,2,7,12):
            for cols in (1,2,9,18):
                tiles=list(g.clipped_courses(4.8,7.2,rows,cols))
                self.assertEqual(len(tiles),rows*cols+rows//2)
                for row,column,d0,d1,u0,u1 in tiles:
                    self.assertTrue(0<=d0<d1<=4.8+1e-10)
                    self.assertTrue(-3.6-1e-10<=u0<u1<=3.6+1e-10)
                if rows>1:
                    a=[x for x in tiles if x[0]==0];b=[x for x in tiles if x[0]==1]
                    self.assertGreater(a[0][3],b[0][2])
                    self.assertLess(b[0][5]-b[0][4],a[0][5]-a[0][4])

    def test_closed_tiles_both_roof_orientations(self):
        for side in (-1,1):
            for side_gable in (False,True):
                for pitch in (.05,.40,.90):
                    for row,col,d0,d1,u0,u1 in g.clipped_courses(4,6,5,9):
                        mesh=g.roof_tile(d0,d1,u0,u1,half_span=4*math.cos(pitch),pitch=pitch,
                                         eave_z=2.4,side=side,side_gable=side_gable,
                                         center_x=2,center_y=-1,thickness=.082)
                        g.validate_mesh(mesh)
                        self.assertTrue(all(math.isfinite(c) for p in mesh.vertices for c in p))

    def test_headlap_underside_clears_previous_course(self):
        # Projected normal offsets of overlapping courses, including crown camber.
        for thickness,camber in ((.075,.007),(.078,.009),(.086,.009)):
            for fraction in (0,.25,.5,.75,1):
                previous_t=(1+.24*fraction)/1.24
                upper_t=.24*fraction/1.24
                previous_top=thickness*(1-.68*previous_t)+camber
                upper_bottom=.62*thickness*(1-.68*upper_t)
                self.assertGreater(upper_bottom,previous_top)

    def test_real_roof_assembly_functions(self):
        calls=[]
        def record(name,*args,**kwargs):calls.append((name,args,kwargs))
        def tile(name,token,root,**kwargs):
            g.validate_mesh(g.roof_tile(**kwargs));record(name,token,**kwargs)
        def cap(name,location,length,token,root,**kwargs):
            g.validate_mesh(g.ridge_cap(length));record(name,location,length)
        env={name:record for name in ('add_box','add_crafted_box','add_tri_prism','_add_rect_brace')}
        env.update(add_roof_tile=tile,add_ridge_cap=cap,clipped_courses=g.clipped_courses)
        functions=load_functions('architecture.py',[
            '_architecture_shingle_rows','_side_shingle_rows','_add_tiled_canopy',
            '_shingled_gable_roof','_side_shingled_gable_roof'],env)
        functions['_architecture_shingle_rows']('main',6,8,3.2,38,['clay','warm','shade'],None,
                                              rows=8,columns=12,seed=7)
        functions['_side_shingle_rows']('side',8,6,3.2,38,'clay',None,rows=8,columns=12,seed=7)
        functions['_shingled_gable_roof']('mainroof',6,8,3.2,38,'clay','wood',None)
        functions['_side_shingled_gable_roof']('sideroof',8,6,3.2,38,'clay','wood',None,
                                             overhang_front=.5,overhang_side=.5,courses=8,course_thickness=.16,bevel=.02)
        for detail in (True,False):
            functions['_add_tiled_canopy'](f'porch{detail}',2,-3,4,2.4,2.5,22,'clay','wood',None,detail=detail,seed=4)
        names=[c[0] for c in calls]
        self.assertEqual(len(names),len(set(names)))
        self.assertGreater(len(names),400)


class RecipeTests(unittest.TestCase):
    def setUp(self):
        self.records=[]
        self.clouds=load_functions('clouds.py',['_build_cloud_recipe','_build_bank','_build_tower','_scaled','_required','_token'],
                                  {'_add_lobe':lambda *a,**k:self.records.append((a,k))})
        self.fish=load_functions('fish.py',['_smoothstep','_longitudinal_profile','_flank_point'])

    def cloud_spec(self,count):
        return {'seed':4,'palette':['cloud_token'],'parameters':{'width':10,'depth':6,'height':4,'clusters':count}}

    def test_clouds_obey_count_and_have_bounded_extras(self):
        for kind in ('bank','tower'):
            for count in (1,4,8,12,30,100):
                self.records.clear();self.clouds['_build_'+kind](self.cloud_spec(count),None)
                self.assertEqual(len(self.records),count)
                for args,kwargs in self.records:
                    loc,scale=args[1:3]
                    self.assertLess(abs(loc[0])+scale[0],8)
                    self.assertLess(abs(loc[1])+scale[1],5)
                    self.assertLess(abs(loc[2])+scale[2],3)

    def test_cloud_count_growth_is_prefix_stable(self):
        self.clouds['_build_bank'](self.cloud_spec(8),None);old=list(self.records)
        self.records.clear();self.clouds['_build_bank'](self.cloud_spec(18),None)
        self.assertEqual(old,self.records[:8])

    def test_bank_and_tower_are_distinct(self):
        self.clouds['_build_bank'](self.cloud_spec(8),None);bank=list(self.records)
        self.records.clear();self.clouds['_build_tower'](self.cloud_spec(8),None)
        self.assertNotEqual([r[0][1:3] for r in bank],[r[0][1:3] for r in self.records])

    def test_invalid_cloud_dimensions_and_count(self):
        for key,value in (('height',0),('width',math.inf),('clusters',0),('clusters',1.5)):
            spec=self.cloud_spec(8);spec['parameters'][key]=value
            with self.assertRaises(ValueError):self.clouds['_build_bank'](spec,None)

    def test_fish_projection_is_finite_symmetric_and_species_specific(self):
        p={'length':2,'girth':.3,'bodyDepth':.9,'tailPeduncle':.12,'bodySegments':20,'radialSegments':12}
        species=('trout','catfish','pike','arowana','tuna','sturgeon','sailfish','swordfish','blue_marlin','amberjack','sardine','sea_bream')
        widths=[]
        for kind in species:
            for y in (-.8,-.58,0,.5,.9):
                for h in (-.48,0,.42,.51):
                    left=self.fish['_flank_point'](kind,p,y,h,-1)
                    right=self.fish['_flank_point'](kind,p,y,h,1)
                    self.assertEqual(left[0],-right[0]);self.assertEqual(left[1:],right[1:])
                    self.assertTrue(all(math.isfinite(c) for c in left))
                    self.assertLess(abs(left[0]),p['girth']*1.11)
            widths.append(self.fish['_flank_point'](kind,p,-.8,.42,1)[0])
        self.assertGreater(len(set(widths)),5)

    def test_fish_projection_tracks_sampled_ring_vertices(self):
        p={'length':2,'girth':.3,'bodyDepth':.9,'tailPeduncle':.12,'bodySegments':20,'radialSegments':12}
        for i in (3,8,13,18):
            progress=i/20;position=progress*2-1;radius=self.fish['_longitudinal_profile']('trout',position,.12)
            for a in (-math.pi/6,0,math.pi/6):
                point=self.fish['_flank_point']('trout',p,position,math.sin(a),1)
                self.assertAlmostEqual(point[0],math.cos(a)*.3*radius*(.96+.04*math.cos(2*a)))
                self.assertAlmostEqual(point[2],math.sin(progress*math.pi)*.3*.055+math.sin(a)*.3*.9*radius)


class SourceContractTests(unittest.TestCase):
    def test_all_python_compiles(self):
        for filename in GEN.glob('*.py'):
            compile(filename.read_text(),str(filename),'exec')

    def test_existing_function_signatures_preserved(self):
        for filename,data in CONTRACTS['files'].items():
            tree=ast.parse((GEN/filename).read_text())
            current={n.name:[ast.dump(n.args,include_attributes=False),ast.dump(n.returns,include_attributes=False) if n.returns else None]
                     for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
            for name,signature in data['signatures'].items():
                self.assertEqual(signature,current[name],f'{filename}:{name}')

    def test_marker_collision_skinning_and_clip_calls_preserved(self):
        protected=set(CONTRACTS['protected_calls'])
        for filename,data in CONTRACTS['files'].items():
            tree=ast.parse((GEN/filename).read_text())
            calls=sorted(ast.dump(n,include_attributes=False) for n in ast.walk(tree)
                         if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in protected)
            self.assertEqual(digest('\n'.join(calls)),data['protected_calls_sha256'],filename)

    def test_registry_and_importer_are_byte_identical(self):
        for filename in ('registry.py','imported.py'):
            self.assertEqual(digest((GEN/filename).read_text()),CONTRACTS['files'][filename]['original_sha256'])

    def test_no_typescript_or_javascript_payload(self):
        files=list((ROOT/'tools').rglob('*'))
        self.assertFalse([p for p in files if p.suffix in {'.ts','.tsx','.js','.mjs','.mts'}])

    def test_declared_module_hashes_match(self):
        for name,data in CONTRACTS['files'].items():
            self.assertEqual(digest((GEN/name).read_text()),data['updated_sha256'],name)


if __name__ == '__main__':
    unittest.main(verbosity=2)
