#!/usr/bin/env python3
"""Hash-guarded, per-module installer. Dry-run unless --apply is explicit.

Writes only the selected Python generators and the two new shared helpers.
Never regenerates assets, publishes GLBs, edits TypeScript, or changes Git state.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid

PACKAGE = Path(__file__).resolve().parent
BLENDER_REL = Path('tools/blender')
GEN_REL = BLENDER_REL/'generators'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write(destination: Path, data: bytes) -> None:
    mode = destination.stat().st_mode & 0o777 if destination.exists() else 0o644
    descriptor, temp_name = tempfile.mkstemp(prefix='.neva-upgrade-', dir=destination.parent)
    temporary = Path(temp_name)
    try:
        with os.fdopen(descriptor,'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.chmod(mode)
        os.replace(temporary,destination)
    finally:
        temporary.unlink(missing_ok=True)


def make_plan(repo: Path, files: list[str], manifest: dict) -> list[dict]:
    folder = repo/GEN_REL
    if not folder.is_dir():
        raise ValueError(f'Generator directory not found: {folder}')
    if not folder.resolve().is_relative_to(repo):
        raise ValueError('Generator directory resolves outside the selected repository')
    plan=[]
    for name in files:
        if Path(name).name != name or not name.endswith('.py'):
            raise ValueError(f'Unsafe manifest path: {name!r}')
        entry=manifest['files'][name]
        relative=Path(entry['path'])
        expected_folder = BLENDER_REL/'common' if name in manifest['helpers'] else GEN_REL
        if relative != expected_folder/name:
            raise ValueError(f'Unexpected manifest destination: {relative}')
        source=PACKAGE/relative
        content=source.read_bytes()
        if sha(content)!=entry['updated_sha256']:
            raise ValueError(f'Package integrity check failed: {name}')
        target=repo/relative
        if not target.parent.is_dir() or not target.parent.resolve().is_relative_to(repo):
            raise ValueError(f'Target parent is missing or resolves outside the repository: {target.parent}')
        if target.is_symlink():
            raise ValueError(f'Refusing to replace a symlink: {target}')
        before=target.read_bytes() if target.exists() else None
        current=sha(before) if before is not None else None
        if current==entry['updated_sha256']:
            status='already updated'
        elif current==entry['original_sha256']:
            status='install' if before is None else 'update'
        else:
            raise ValueError(
                f'{name}: your repository differs from the uploaded baseline. '
                'Nothing has been changed. Review patches/'+name+'.patch and merge this file manually; '
                'do not overwrite your newer work.')
        plan.append({'name':name,'relative':relative,'target':target,'before':before,'after':content,'status':status})
    return plan


def apply_plan(repo: Path, plan: list[dict]) -> Path | None:
    pending=[item for item in plan if item['status']!='already updated']
    if not pending:
        return None
    # Recheck immediately before the transaction; fail rather than clobber edits.
    for item in pending:
        current=item['target'].read_bytes() if item['target'].exists() else None
        if current!=item['before']:
            raise ValueError(f'{item["name"]} changed after the preflight check')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    backup=repo/'.neva-generator-backups'/stamp
    backup.mkdir(parents=True,exist_ok=False)
    report={'created_utc':stamp,'files':[],'status':'prepared'}
    for item in pending:
        if item['before'] is not None:
            (backup/item['name']).write_bytes(item['before'])
        report['files'].append({'name':item['name'],'path':str(item['relative']),'existed':item['before'] is not None,
                                'before_sha256':sha(item['before']) if item['before'] is not None else None,
                                'after_sha256':sha(item['after'])})
    (backup/'transaction.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    written=[]
    try:
        for item in pending:
            # Reject an editor save that happened while earlier files were installed.
            current=item['target'].read_bytes() if item['target'].exists() else None
            if current!=item['before']:
                raise ValueError(f'{item["name"]} changed during installation')
            atomic_write(item['target'],item['after'])
            written.append(item)
    except Exception:
        errors=[]
        for item in reversed(written):
            try:
                if item['target'].read_bytes()!=item['after']:
                    raise ValueError('file was edited after installation; left untouched')
                if item['before'] is None:
                    item['target'].unlink()
                else:
                    atomic_write(item['target'],item['before'])
            except Exception as error:
                errors.append(f'{item["name"]}: {error}')
        report['status']='rollback incomplete' if errors else 'rolled back'
        report['rollback_errors']=errors
        (backup/'transaction.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        if errors:
            raise RuntimeError(f'Installation failed; inspect backup {backup}. '+ '; '.join(errors))
        raise
    report['status']='applied'
    (backup/'transaction.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return backup


def main(argv=None) -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True,help='Local NEVA repository root')
    selection=parser.add_mutually_exclusive_group(required=True)
    selection.add_argument('--module',action='append',help='One module (repeatable), for example architecture or fish.py')
    selection.add_argument('--all',action='store_true',help='Explicitly select all 18 changed visual modules')
    parser.add_argument('--apply',action='store_true',help='Write changes after all selected hashes pass; default is dry-run')
    args=parser.parse_args(argv)
    try:
        repo=args.repo.expanduser().resolve(strict=True)
        manifest=json.loads((PACKAGE/'upgrade_manifest.json').read_text(encoding='utf-8'))
        allowed=manifest['changed_modules']
        requested=allowed if args.all else list(dict.fromkeys(n if n.endswith('.py') else n+'.py' for n in args.module))
        unknown=set(requested)-set(allowed)
        if unknown:
            raise ValueError(f'Not a changed visual module: {", ".join(sorted(unknown))}')
        files=list(manifest['helpers'])+requested
        plan=make_plan(repo,files,manifest)
        for item in plan:
            print(f'{item["status"]:16} {item["relative"]}')
        if not args.apply:
            print('DRY RUN: no files were written. Repeat with --apply to install this selection.')
            return 0
        backup=apply_plan(repo,plan)
        print(f'Applied. Original files backed up to: {backup}' if backup else 'No writes needed; this selection is already installed.')
        print('No GLBs were generated or published. Run the catalog impact check, then the selected art CLI.')
        return 0
    except (OSError,ValueError,KeyError,RuntimeError) as error:
        print(f'ERROR: {error}',file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
