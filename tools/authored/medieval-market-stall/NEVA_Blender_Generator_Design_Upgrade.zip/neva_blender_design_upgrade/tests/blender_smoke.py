"""Run inside the user's Blender AFTER installing the selected Python upgrade.

blender --background --factory-startup --python-exit-code 1 \
  --python /path/to/package/tests/blender_smoke.py -- --repo /path/to/nevagame

Builds isolated primitive samples, checks real Blender topology/attributes and
exports a temporary GLB. Does not publish, modify the catalog, or save a scene.
This script was supplied but NOT executed in the authoring session.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import struct
import sys
import tempfile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    repo=args.repo.expanduser().resolve(strict=True)
    sys.path.insert(0,str(repo/'tools/blender'))
    import bpy
    import bmesh
    from common.geometry import finish_authored_surface
    from common.design_primitives import (add_crafted_box,add_roof_tile,add_ridge_cap,
        add_folded_leaf,add_canopy_mass,add_geological_mass,add_lobed_volume,add_hat_brim,add_draped_panel)
    palette=json.loads((repo/'art/palettes/neva.palette.json').read_text())
    token=next(iter(palette['tokens']))
    root=bpy.data.objects.new('NEVA_upgrade_smoke_root',None)
    bpy.context.collection.objects.link(root)
    root.location=(3,-1,2)
    objects=[
        add_crafted_box('test_timber',(0,0,0),(.2,.3,3),token,root,rotation=(.1,.2,.3)),
        add_crafted_box('test_hard_box',(0,0,0),(.2,.3,3),token,root,bevel=0),
        add_roof_tile('test_clay',token,root,d0=0,d1=.6,u0=-.2,u1=.2,
                      half_span=2,pitch=.6,eave_z=2,side=1),
        add_ridge_cap('test_cap',(0,0,0),.6,token,root),
        add_folded_leaf('test_leaf',(0,0,0),.8,.2,.4,token,root),
        add_canopy_mass('test_canopy',(0,0,0),(2,1.4,.8),token,root),
        add_geological_mass('test_stone',(0,0,0),(2,1,1.4),token,root),
        add_lobed_volume('test_fruit',(0,0,0),(.16,.15,.16),token,root,sides=8),
        add_hat_brim('test_brim',(0,0,0),.17,.365,token,root),
        add_draped_panel('test_apron',(0,0,0),(.58,.04,.52),token,root),
    ]
    bpy.context.view_layer.update()
    evidence=[]
    for obj in objects:
        assert obj.parent is root, obj.name
        assert all(abs(v-1)<1e-7 for v in obj.scale), obj.name
        assert all(abs(v)<1e-7 for v in obj.rotation_euler), obj.name
        assert len(obj.data.materials)==1, obj.name
        assert obj.data.color_attributes.get('Color') is not None,obj.name
        assert obj.data.attributes.get('.neva_surface') is not None,obj.name
        mesh=bmesh.new()
        try:
            mesh.from_mesh(obj.data)
            assert all(e.is_manifold for e in mesh.edges),obj.name
            assert all(f.calc_area()>1e-12 for f in mesh.faces),obj.name
            assert mesh.calc_volume(signed=True)>0,obj.name
        finally:
            mesh.free()
        finish_authored_surface(obj,root)
        obj.data.calc_loop_triangles()
        evidence.append({'name':obj.name,'vertices':len(obj.data.vertices),
                         'triangles':len(obj.data.loop_triangles)})
    for obj in bpy.context.view_layer.objects:
        obj.select_set(False)
    root.select_set(True)
    for obj in objects:obj.select_set(True)
    bpy.context.view_layer.objects.active=root
    with tempfile.TemporaryDirectory(prefix='neva-upgrade-smoke-') as directory:
        path=Path(directory)/'smoke.glb'
        result=bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True)
        assert 'FINISHED' in result,result
        data=path.read_bytes()
        magic,version,total=struct.unpack_from('<4sII',data,0)
        assert magic==b'glTF' and version==2 and total==len(data)
        size,kind=struct.unpack_from('<I4s',data,12)
        assert kind==b'JSON'
        document=json.loads(data[20:20+size].decode('utf-8'))
        primitives=[p for m in document['meshes'] for p in m['primitives']]
        assert primitives
        for primitive in primitives:
            assert {'POSITION','NORMAL','COLOR_0'}<=set(primitive['attributes']),primitive
        evidence_report={'status':'passed','blender_version':bpy.app.version_string,
                         'primitive_checks':evidence,'glb_mesh_primitives':len(primitives),
                         'glb_bytes':len(data),'scope':'isolated helpers only; not full catalog/export optimisation/game approval'}
    text=json.dumps(evidence_report,indent=2)
    print(text)
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(text+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
