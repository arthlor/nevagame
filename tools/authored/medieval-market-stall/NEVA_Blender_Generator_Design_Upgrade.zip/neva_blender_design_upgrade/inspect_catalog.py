#!/usr/bin/env python3
"""Read-only impact report from the user's actual catalog and Python registry.

No Blender imports; no catalog edits; no asset publication. Recognises direct
owners and transitive imports between generator modules. Prebuilt and imported
art remains excluded, even when it shares a family with procedural generators.
"""
from __future__ import annotations
import argparse
import ast
import json
from pathlib import Path
import shlex
import sys

PACKAGE=Path(__file__).resolve().parent


def registry_map(path: Path) -> dict[str,str]:
    tree=ast.parse(path.read_text(encoding='utf-8'))
    imports={alias.asname or alias.name:n.module+'.py' for n in tree.body
             if isinstance(n,ast.ImportFrom) and n.level==1 and n.module
             for alias in n.names}
    result={}
    for node in tree.body:
        if isinstance(node,(ast.Assign,ast.AnnAssign)):
            targets=node.targets if isinstance(node,ast.Assign) else [node.target]
            if not any(isinstance(t,ast.Name) and t.id=='GENERATORS' for t in targets):
                continue
            if not isinstance(node.value,ast.Dict):
                raise ValueError('GENERATORS is not a literal dictionary; manual impact review is required')
            for key,value in zip(node.value.keys,node.value.values):
                if isinstance(key,ast.Constant) and isinstance(key.value,str) and isinstance(value,ast.Name):
                    if value.id in imports:
                        result[key.value]=imports[value.id]
    if not result:
        raise ValueError('Could not resolve any registered Python generator owners')
    return result


def impacted_modules(folder: Path, selected: set[str]) -> set[str]:
    dependencies={}
    for file in folder.glob('*.py'):
        tree=ast.parse(file.read_text(encoding='utf-8'))
        dependencies[file.name]={n.module.split('.')[0]+'.py' for n in ast.walk(tree)
                                  if isinstance(n,ast.ImportFrom) and n.level==1 and n.module}
    impacted=set(selected)
    while True:
        expanded=impacted|{name for name,deps in dependencies.items() if deps&impacted}
        if expanded==impacted:
            return impacted
        impacted=expanded


def inspect(repo: Path, selected: set[str]) -> dict:
    folder=repo/'tools/blender/generators'
    owners=registry_map(folder/'registry.py')
    affected=impacted_modules(folder,selected)
    catalog=json.loads((repo/'assets/specs/asset-catalog.json').read_text(encoding='utf-8'))
    items=catalog['assets'] if isinstance(catalog,dict) else catalog
    results=[]
    for asset in items:
        generator=asset.get('generator','')
        owner=owners.get(generator)
        if generator in {'prebuilt_glb','imported_blend'}:
            reason='protected source asset; Python design changes do not reauthor its source'
            scope=False
        elif owner is None:
            reason='not mapped to a registered Python owner; leave untouched'
            scope=False
        else:
            scope=owner in affected
            reason=('direct owner' if owner in selected else 'transitive Python dependency') if scope else 'unaffected Python generator'
        results.append({'id':asset['id'],'family':asset.get('family'),'generator':generator,'owner':owner,
                        'in_scope':scope,'reason':reason,'budget':asset.get('budget'),
                        'command':f'npm run art:generate -- --asset {shlex.quote(asset["id"])} --no-publish' if scope else None})
    return {'selected_modules':sorted(selected),'impacted_modules':sorted(affected),
            'in_scope_count':sum(a['in_scope'] for a in results),'assets':results}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--module',action='append',help='Changed module name; repeatable')
    group.add_argument('--all',action='store_true')
    parser.add_argument('--json',action='store_true',help='Print the full machine-readable report')
    parser.add_argument('--commands',action='store_true',help='Print selected no-publish commands only; does not execute them')
    parser.add_argument('--show-excluded',action='store_true')
    args=parser.parse_args(argv)
    try:
        manifest=json.loads((PACKAGE/'upgrade_manifest.json').read_text(encoding='utf-8'))
        selected=set(manifest['changed_modules'] if args.all else (n if n.endswith('.py') else n+'.py' for n in args.module))
        if selected-set(manifest['changed_modules']):
            raise ValueError('Select only changed modules listed in upgrade_manifest.json')
        report=inspect(args.repo.expanduser().resolve(strict=True),selected)
        if args.json:
            print(json.dumps(report,indent=2))
        elif args.commands:
            for item in report['assets']:
                if item['command']:print(item['command'])
        else:
            print(f'{report["in_scope_count"]} catalog entries use the selected Python changes (directly or transitively).')
            for item in report['assets']:
                if item['in_scope'] or args.show_excluded:
                    print(f'{"AFFECTED" if item["in_scope"] else "SKIP":8} {item["id"]:42} {item["generator"]:24} {item["reason"]}')
            print('Prebuilt GLBs, imported source art, and unmapped runtime procedural assets are not reauthored.')
            print('Review catalog triangle bounds and LOD ratios; no budgets are relaxed by this package.')
        return 0
    except (ValueError,KeyError,OSError,SyntaxError) as error:
        print(f'ERROR: {error}',file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
