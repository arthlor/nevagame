from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

PACKAGE=Path(__file__).resolve().parents[1]


def sha(data):return hashlib.sha256(data).hexdigest()


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        root=Path(self.temp.name)
        self.package=root/'package';self.repo=root/'repo'
        for base in (self.package,self.repo):
            (base/'tools/blender/generators').mkdir(parents=True)
            (base/'tools/blender/common').mkdir(parents=True)
        shutil.copyfile(PACKAGE/'apply_upgrade.py',self.package/'apply_upgrade.py')
        self.old=b'OLD\n';self.new=b'NEW\n'
        self.target=self.repo/'tools/blender/generators/architecture.py'
        self.target.write_bytes(self.old)
        files={}
        for name,folder,before,after in [
            ('architecture.py','generators',self.old,self.new),
            ('design_geometry.py','common',None,b'GEOMETRY\n'),
            ('design_primitives.py','common',None,b'ADAPTER\n'),
        ]:
            rel=f'tools/blender/{folder}/{name}'
            (self.package/rel).write_bytes(after)
            files[name]={'path':rel,'original_sha256':sha(before) if before else None,'updated_sha256':sha(after)}
        (self.package/'upgrade_manifest.json').write_text(json.dumps({
            'helpers':['design_geometry.py','design_primitives.py'],
            'changed_modules':['architecture.py'],'files':files}))

    def tearDown(self):self.temp.cleanup()

    def run_tool(self,*flags):
        return subprocess.run([sys.executable,str(self.package/'apply_upgrade.py'),'--repo',str(self.repo),*flags],capture_output=True,text=True)

    def test_default_is_read_only(self):
        result=self.run_tool('--module','architecture')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(self.target.read_bytes(),self.old)
        self.assertFalse((self.repo/'tools/blender/common/design_geometry.py').exists())
        self.assertFalse((self.repo/'.neva-generator-backups').exists())

    def test_apply_backs_up_originals_and_is_idempotent(self):
        result=self.run_tool('--module','architecture','--apply')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(self.target.read_bytes(),self.new)
        backups=list((self.repo/'.neva-generator-backups').glob('*/architecture.py'))
        self.assertEqual(len(backups),1)
        self.assertEqual(backups[0].read_bytes(),self.old)
        result=self.run_tool('--module','architecture.py','--apply')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(len(list((self.repo/'.neva-generator-backups').iterdir())),1)

    def test_changed_local_source_refuses_all_writes(self):
        self.target.write_bytes(b'MY NEWER WORK\n')
        result=self.run_tool('--module','architecture','--apply')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(self.target.read_bytes(),b'MY NEWER WORK\n')
        self.assertFalse((self.repo/'tools/blender/common/design_geometry.py').exists())

    def test_corrupt_payload_refuses_all_writes(self):
        (self.package/'tools/blender/generators/architecture.py').write_bytes(b'CORRUPT')
        result=self.run_tool('--module','architecture','--apply')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(self.target.read_bytes(),self.old)
        self.assertFalse((self.repo/'tools/blender/common/design_geometry.py').exists())

    def test_protected_module_cannot_be_selected(self):
        result=self.run_tool('--module','registry','--apply')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(self.target.read_bytes(),self.old)

    def test_symlink_target_refused(self):
        other=self.repo/'other.py';other.write_bytes(self.old)
        self.target.unlink();self.target.symlink_to(other)
        result=self.run_tool('--module','architecture','--apply')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(other.read_bytes(),self.old)


class CatalogScopeTests(unittest.TestCase):
    def test_direct_indirect_and_protected_routes(self):
        spec=importlib.util.spec_from_file_location('upgrade_scope',PACKAGE/'inspect_catalog.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);folder=root/'tools/blender/generators';folder.mkdir(parents=True)
            (folder/'registry.py').write_text('from .crops import wheat\nfrom .woodland import reeds\nfrom .imported import imported_blend\nGENERATORS={"wheat":wheat,"reeds":reeds,"imported_blend":imported_blend}\n')
            (folder/'crops.py').write_text('def wheat(): pass\n')
            (folder/'woodland.py').write_text('from .crops import wheat\ndef reeds(): pass\n')
            (folder/'imported.py').write_text('def imported_blend(): pass\n')
            (root/'assets/specs').mkdir(parents=True)
            (root/'assets/specs/asset-catalog.json').write_text(json.dumps({'assets':[
                {'id':'crop_wheat','generator':'wheat'},
                {'id':'reeds','generator':'reeds'},
                {'id':'prebuilt_cottage','generator':'prebuilt_glb'},
                {'id':'source_npc','generator':'imported_blend'},
                {'id':'ts_water','generator':'runtime_procedural_ts'},
            ]}))
            report=module.inspect(root,{'crops.py'})
            rows={x['id']:x for x in report['assets']}
            self.assertEqual(report['in_scope_count'],2)
            self.assertEqual(rows['crop_wheat']['reason'],'direct owner')
            self.assertEqual(rows['reeds']['reason'],'transitive Python dependency')
            self.assertFalse(rows['prebuilt_cottage']['in_scope'])
            self.assertFalse(rows['source_npc']['in_scope'])
            self.assertFalse(rows['ts_water']['in_scope'])
            self.assertTrue(all('--no-publish' in x['command'] for x in rows.values() if x['in_scope']))


if __name__=='__main__':unittest.main(verbosity=2)
